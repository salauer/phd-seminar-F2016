.onAttach <- function(...) {

  if (!interactive()) return()

  # packageStartupMessage(paste0("cdcfluview is under *active* development. ",
  #                              "There are *breaking changes*. ",
  #                              "See https://github.com/hrbrmstr/cdcfluview for info/news."))

}

