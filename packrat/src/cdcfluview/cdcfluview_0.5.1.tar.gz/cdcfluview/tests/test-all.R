library(testthat)
test_check("cdcfluview")
